package ExerciciosJava;

//Faça um algoritmo que leia a idade de uma pessoa expressa em anos, meses e dias e
//        mostre-a expressa em dias. Leve em consideração o ano com 365 dias e o mês com 30.
//        (Ex: 3 anos, 2 meses e 15 dias = 1170 dias.)

import java.util.Scanner;

public class Ex1 {

    public static void main(String[] args) {

        int idade;
        int idadeMeses;
        int idadeDias;

        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a sua idade em anos");
        idade = sc.nextInt();
        System.out.println("Digite a sua idade em meses");
        idadeMeses = sc.nextInt();
        System.out.println("Digite a sua idade em dias");
        idadeDias = sc.nextInt();


        int qtd_meses = idadeMeses(idadeMeses);
        int qtd_dias = idadeDias(idadeDias);
        int qtd_anos = idadeAnos(idade);

        System.out.println(qtd_anos + qtd_meses + qtd_dias);


    }

    public static int idadeMeses(int idadeMeses){
        return idadeMeses * 30;
    }

    public static int idadeAnos(int idade){
            return idade * 365;
        }

    public static int idadeDias(int idadeDias){
        return idadeDias;
    }

}
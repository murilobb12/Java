package ExerciciosJava;

import java.math.BigDecimal;
import java.util.Scanner;

public class Ex2 {


    public static void main(String[] args) {

        BigDecimal saldo = BigDecimal.ZERO;

        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o seu salário");
        saldo = sc.nextBigDecimal().multiply(new BigDecimal(1.01));


        System.out.printf("O seu salário com reajuste de 1 por cento é %.2f", saldo );



    }

}

package explicacao.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TestandoCollections {

        public static void main(String[] args) {



            ArrayList<Integer> lista = new ArrayList<>();

            lista.add(1);
            lista.add(2);
            lista.add(3);
            lista.add(7);
            lista.add(5);
            lista.add(10);


            System.out.println(lista);

            lista.remove(lista.size()-1);
            Collections.sort(lista);

            System.out.println(lista);




        }


}

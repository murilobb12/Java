package bankAccount;

public class Mensageria {

    public void sendOTP(String medium) {
        if (medium.equals("email")) {
            // Send an email
        }
    }


}

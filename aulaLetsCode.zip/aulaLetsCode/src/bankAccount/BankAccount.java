package bankAccount;

import java.math.BigDecimal;
import java.security.InvalidParameterException;

public class BankAccount {

    private final int numeroConta;
    private BigDecimal saldo;

    public BankAccount(final int numeroConta, final BigDecimal saldo) {
        this.numeroConta = numeroConta;
        this.setSaldo(saldo);
    }


    public int getNumeroConta() {
        return numeroConta;
    }

    public BigDecimal getSaldo() {
        return saldo;
    }

    public void setSaldo(BigDecimal saldo) {
        if (saldo.compareTo(new BigDecimal("0")) == 1) {
            this.saldo = saldo;
        }
    }

    @Override
    public String toString() {
        return saldo +" "+ numeroConta;
    }
}

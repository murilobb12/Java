package bankAccount;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class App {

    public static void main(String[] args) {

        final Map<Integer, BankAccount> bankAccounts = new HashMap<>();

        bankAccounts.put(3, new BankAccount(999, new BigDecimal("999")));

        bankAccounts.put(1,new BankAccount(123, new BigDecimal("500")));
        bankAccounts.put(2,new BankAccount(456, new BigDecimal("500")));

        Movimentacao movimentacao = new Movimentacao(123, new BigDecimal("500"));

        movimentacao.deposit(new BigDecimal("-123"), bankAccounts.get(1));

        System.out.println(bankAccounts);








    }


}

package contasSolid.contas;

import contasSolid.clientes.Cliente;

public class ContaPoupanca extends Conta {


    public ContaPoupanca(String numeroConta, Cliente titular) {
        super(numeroConta, titular);
    }
}

package contasSolid.contas;

import contasSolid.clientes.Cliente;
import contasSolid.contas.exception.ContaException;

import java.math.BigDecimal;
import java.security.InvalidParameterException;

public abstract class Conta {

    private final  String numeroConta;
    private BigDecimal saldo = BigDecimal.ZERO;
    private Cliente titular;


    public Conta(String numeroConta, Cliente titular) {
        this.numeroConta = numeroConta;
        this.titular = titular;
    }

    public BigDecimal sacar(BigDecimal valor) throws ContaException {
        validarValorTransacao(valor);

        if(saldo.subtract(valor).compareTo(BigDecimal.ZERO) < 0){
            throw ContaException.saldoInsuficiente();
        }
        saldo = saldo.subtract(valor);
        return saldo;

    }


    public BigDecimal depositar(BigDecimal valor) {
        validarValorTransacao(valor);
        saldo = saldo.add(valor);
        return saldo;
    }

    public void transferir(BigDecimal valor, Conta numeroContaDestino) throws ContaException{
        if(numeroContaDestino == null){
            throw ContaException.contaInvalida();
        }
        this.sacar(valor);
        numeroContaDestino.depositar(valor);

    }

    private void validarValorTransacao(BigDecimal valor){
        if (valor.compareTo(BigDecimal.ZERO) < 0) {
            throw new InvalidParameterException("Valor Negativo");
        }

    }


}

package contasSolid.clientes;

public class ClientePJ extends Cliente{


    public ClientePJ(String nome, String numeroDocumento) {
        super(nome, numeroDocumento);
    }
}

package contasSolid.clientes;

public class ClientePF extends Cliente{

    public ClientePF(String nome, String numeroDocumento) {
        super(nome, numeroDocumento);
    }
}

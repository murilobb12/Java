package contasSolid;

import contasSolid.clientes.Cliente;
import contasSolid.clientes.ClientePF;
import contasSolid.contas.Conta;

public class App {

    public static void main(String[] args) {

        Cliente murilo = new ClientePF("Murilo", "38230414874");

//        Conta contaMurilo = new Conta("123456", murilo);

//        contaMurilo.sacar();



    }


}

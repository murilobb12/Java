package DevDojo.Explicacao.ModificadorStatic;

public class AnimeApp {

    public static void main(String[] args) {

        Anime anime = new Anime();
        Anime anime2 = new Anime();
        Anime anime3 = new Anime();



    }

}

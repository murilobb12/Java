package DevDojo.Explicacao.Introducao;

public class Arrays {

    public static void main(String[] args) {

//        int[] idades = {1, 2, 3};
        int idades[] = {1,2,3,4};

        for (int i: idades
             ) {
            System.out.println(i);

        }

    }

}

package DevDojo.Explicacao.Introducao;

public class EstruturaRepeticao {
    public static void main(String[] args) {
        // while, for
//        int count = 0;
//        while (count < 10){
//            System.out.println(++count);
//        }

        for (int count = 0; count <10; count++){
            System.out.println(count);
        }



    }
}

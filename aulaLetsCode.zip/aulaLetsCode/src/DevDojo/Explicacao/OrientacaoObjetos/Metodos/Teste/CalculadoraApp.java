package DevDojo.Explicacao.OrientacaoObjetos.Metodos.Teste;

import DevDojo.Explicacao.OrientacaoObjetos.Metodos.Dominio.Calculadora;

public class CalculadoraApp {
    public static void main(String[] args) {

        Calculadora c = new Calculadora();

        c.somaDoisNumeros(1,2);
        c.subtraiDoisNumeros(2,1);
        c.multiplicaDoisNumeros(2,1);



    }

}

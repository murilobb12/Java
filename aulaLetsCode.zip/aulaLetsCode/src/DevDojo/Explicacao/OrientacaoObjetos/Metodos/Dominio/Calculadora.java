package DevDojo.Explicacao.OrientacaoObjetos.Metodos.Dominio;

public class Calculadora {

    public void somaDoisNumeros(int n1, int n2){
        int soma = n1 + n2;

        System.out.println(soma);
    }

    public void subtraiDoisNumeros(int n1, int n2){
        int subtracao = n1 - n2;

        System.out.println(subtracao);
    }

    public void multiplicaDoisNumeros(int n1, int n2){
        int multiplicacao = n1 * n2;

        System.out.println(multiplicacao);
    }

}

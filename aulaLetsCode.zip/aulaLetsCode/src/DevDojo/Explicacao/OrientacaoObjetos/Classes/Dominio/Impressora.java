package DevDojo.Explicacao.OrientacaoObjetos.Classes.Dominio;

public class Impressora {

    public void imprimeEstudante(Estudante e){

        System.out.println("------------");

        System.out.println(e.nome);
        System.out.println(e.idade);
        System.out.println(e.sexo);
    }


}

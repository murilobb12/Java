package DevDojo.Explicacao.Construtores;

public class AnimeApp {
    public static void main(String[] args) {

        Anime anime = new Anime("Naruto", "Ninja", 547, "Ação", "Konami");

        System.out.println(anime.toString());

    }
}

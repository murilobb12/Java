package DevDojo.Explicacao.BlocosInicializacao;

public class AnimeApp {

    public static void main(String[] args) {

        Anime anime = new Anime();



    }

}

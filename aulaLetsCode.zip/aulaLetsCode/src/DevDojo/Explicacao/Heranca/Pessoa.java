package DevDojo.Explicacao.Heranca;

public class Pessoa {

}

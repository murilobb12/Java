package DevDojo.Explicacao.Heranca;

public class Funcionario {

    private String nome;
    private String cpf;


}

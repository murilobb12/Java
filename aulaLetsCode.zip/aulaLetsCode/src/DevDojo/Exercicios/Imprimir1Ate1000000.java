package DevDojo.Exercicios;

public class Imprimir1Ate1000000 {

    public static void main(String[] args) {
    // Imprimir todos os números pares de 1 ate 1000000

        int inicio = 0;
        int fim = 100;

        for (inicio = inicio ; inicio<= fim; inicio+=2){

            System.out.println(inicio);
        }

    }

}

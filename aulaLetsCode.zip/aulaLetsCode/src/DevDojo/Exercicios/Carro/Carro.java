package DevDojo.Exercicios.Carro;

public class Carro {

    public String nome;
    public String modelo;
    public int ano;



}

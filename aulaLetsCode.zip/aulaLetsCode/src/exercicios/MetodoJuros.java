package exercicios;

public class MetodoJuros {

    public static void main(String[] args) {

        String username = "João";
        double balance = 1000;
        double interstRate = 12.5;
        printInteresForUser(username, balance, interstRate);


    }

    public static void printInteresForUser(String username, double balance, double interesRate){

        double resultado = 2.2;

        resultado = (interesRate/100) * balance;

        resultado = (int)resultado;

        System.out.printf("O %s irá receber R$ %.2f", username, resultado);


    }
}

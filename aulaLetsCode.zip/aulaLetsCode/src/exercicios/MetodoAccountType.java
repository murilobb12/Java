package exercicios;

public class MetodoAccountType {


    public static void main(String[] args) {
        String accountType = "BUSINESS";
        accountType(accountType.toUpperCase().trim());
    }

    static void accountType(String accountType) {
        switch (accountType){
            case "PERSONAL":
                System.out.println("Conta pessoal");
                break;
            case "BUSINESS":
                System.out.println("Conta empresarial");
                break;
            default:
                System.out.println("Tipo de conta não existente");
                break;
        }
    }
}

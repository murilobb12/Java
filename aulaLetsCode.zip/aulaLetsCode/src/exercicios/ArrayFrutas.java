package exercicios;

import java.util.Scanner;

public class ArrayFrutas {

    public static void main(String[] args) {

        String[] frutas = new String[5];
        frutasArray(frutas);
        retornaArray(frutas);
    }

    //Método para colocar as frutas na lista
    public static void frutasArray(String[] frutas){
        Scanner sc = new Scanner(System.in);

        for (int i = 0; i < frutas.length; i++){

            System.out.println("Digite o nome da fruta: ");
            frutas[i] = sc.nextLine();
        }
    }

    //Método para listar o array
    public static void retornaArray(String[] lista){
        for(String f: lista){
            System.out.println(f);
        }
    }

}

package exercicios;

public class Questao1 {

    public static void main(String[] args) {
        final String userName = "João";
        final int balance = 1000;
        final double interestRate = 12.5;

        System.out.printf("O %s irá receber R$%.2f",userName, (interestRate/100)*balance);
    }
}

package exercicios.Agencia;

import java.math.BigDecimal;

public class Conta {

    private BigDecimal saldo;
    private BigDecimal limite;
    private int numeroConta;


    public int getNumeroConta() {
        return numeroConta;
    }

    public BigDecimal getSaldo() {
        return saldo;
    }

    public BigDecimal getLimite() {
        return limite;
    }

    public void setSaldo(BigDecimal saldo) {
        this.saldo = saldo;
    }

    public void setLimite(BigDecimal limite) {
        this.limite = limite;
    }

    public void setNumeroConta(int numeroConta) {
        this.numeroConta = numeroConta;
    }
}

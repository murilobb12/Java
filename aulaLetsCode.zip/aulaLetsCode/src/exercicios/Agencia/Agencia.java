package exercicios.Agencia;

public class Agencia {

    private int Agencia;

    public int getAgencia() {
        return Agencia;
    }

    public void setAgencia(int agencia) {
        Agencia = agencia;
    }
}

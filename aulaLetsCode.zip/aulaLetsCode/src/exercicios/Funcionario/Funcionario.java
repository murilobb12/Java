package exercicios.Funcionario;

import java.math.BigDecimal;

public class Funcionario {

    BigDecimal salario;

    public BigDecimal bonificacao(BigDecimal salario){

        return salario.multiply(new BigDecimal("1.10"));

    }


    public BigDecimal getSalario() {
        return salario;
    }

    public void setSalario(BigDecimal salario) {
        this.salario = salario;
    }




}

package exercicios.Funcionario;

import java.math.BigDecimal;

public class Bonificacao {



    public void Bonus(BigDecimal salario){

        BigDecimal bonus = salario.multiply(new BigDecimal("1.10") );

    }

}

package exercicios.Funcionario;

import java.math.BigDecimal;

public class App {

    public static void main(String[] args) {

        Funcionario f = new Funcionario();
        f.setSalario(new BigDecimal("100.00"));

        System.out.printf("Salário sem bônus %.2f", f.getSalario());
        System.out.printf("\nSalário com Bônus %.2f", f.bonificacao(f.getSalario()));


    }

}

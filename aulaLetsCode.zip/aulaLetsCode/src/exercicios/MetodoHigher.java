package exercicios;

public class MetodoHigher {


    public static void main(String[] args) {
        int n1 = 5;
        int n2 = 10;
        higher(n1, n2);

    }

    static void higher(int n1, int n2) {
        if (n1 > n2) {
            System.out.printf("O maior número é %d", n1);
        } else if(n2 > n1) {
            System.out.printf("O maior número é %d", n2);
        } else {
            System.out.println("Os números são iguais.");
        }
    }
}

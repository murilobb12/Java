package exercicios.Conta;

import java.math.BigDecimal;

public class Conta {

    private int numeroConta;
    private String titular;
    private BigDecimal saldo ;

    public Conta(String titular, int numeroConta){

        if (numeroConta <= 0){
            System.out.println("Número da conta deve ser maior que 0.");
            return;
        }else {
            this.numeroConta = numeroConta;
            this.titular = titular;
            this.saldo =  new BigDecimal(0);

        }

    }

    public void depositar(BigDecimal deposito){
        this.saldo = saldo.add(deposito);
        System.out.println("Depósito realizado com sucesso!");
    }


    public void sacar(BigDecimal saque){
        if (saque.compareTo(saldo) != 1){
            this.saldo = saldo.subtract(saque);
            System.out.println("Saque realizado com sucesso");
        } else {
            System.out.println("Saque negado. Saldo insuficiente.");
        }
    }

    public int getNumeroConta() {
        return numeroConta;
    }

    public void setNumeroConta(int numeroConta) {
        this.numeroConta = numeroConta;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public BigDecimal getSaldo() {
        return saldo;
    }

}
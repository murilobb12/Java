package exercicios.Heranca;

import java.math.BigDecimal;

public class Estagiario extends Funcionario{
    public Estagiario(String nome, BigDecimal salario, int idade, String cpf) {
        super(nome, salario, idade, cpf);
    }

    @Override
    public void calcularPlr(){
        BigDecimal plr = this.salario.multiply(new BigDecimal("2"));
        System.out.println("PLR: R$"+ plr);
    }

}

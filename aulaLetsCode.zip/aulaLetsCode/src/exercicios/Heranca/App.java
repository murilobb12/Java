package exercicios.Heranca;

import java.math.BigDecimal;

public class App {

    public static void main(String[] args) {

    Funcionario murilo = new Funcionario("Murilo", new BigDecimal("4000.00"),27 , "022.253.998-40");

    Gerente g = new Gerente("Paulo", new BigDecimal("10000.00"), 55, "022.253.998-40");

    Estagiario e = new Estagiario("Marcela", new BigDecimal("1500.00"), 17, "478.815.618-07");


        murilo.calcularPlr();
        g.calcularPlr();
        e.calcularPlr();
        System.out.println(murilo);
        System.out.println();
        System.out.println(e);
        System.out.println();
        System.out.println(g);

    }

}

package exercicios.Heranca;

import java.math.BigDecimal;

public class Funcionario {

    protected String nome;
    protected BigDecimal salario;
    protected int idade;
    final String cpf;

    public void calcularPlr(){
        BigDecimal plr = this.salario.multiply(new BigDecimal("3"));
        System.out.println("PLR: R$"+ plr);
    }

    public void calcularFerias(){
        BigDecimal ferias = this.salario.multiply(new BigDecimal("1.3"));
        System.out.println("Ferias: R$"+ ferias);
    }


    public Funcionario(String nome, BigDecimal salario, int idade, String cpf ) {
        this.nome = nome;
        this.salario = salario;
        this.idade = idade;
        this.cpf = cpf;

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public BigDecimal getSalario() {
        return salario;
    }

    public void setSalario(BigDecimal salario) {
        this.salario = salario;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getCpf() {
        return cpf;
    }

    @Override
    public String toString() {
        return "Nome: " + this.nome + "\nIdade: " + this.idade +"\nSalário: R$" + this.salario + "\nCPF: " + this.cpf;
    }
}

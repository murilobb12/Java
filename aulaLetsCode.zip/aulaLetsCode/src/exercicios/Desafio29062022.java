package exercicios;

import java.util.Random;

public class Desafio29062022 {



    public static void main(String[] args) {
        int[][] t = new int[5][5];
        for (int i = 0; i< t.length; i++) {
            for (int j = 0; j<t[0].length;j++) {
                t[i][j] = new Random().nextInt() % 500;
                System.out.println(t[i][j]);

            }

        }








    }


}

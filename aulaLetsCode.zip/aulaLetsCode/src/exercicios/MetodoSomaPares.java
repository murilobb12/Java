package exercicios;

public class MetodoSomaPares {
    public static void main(String[] args) {
        int start = 1;
        int end = 9;
        int soma = 0;
        sumEvenNumbers(start, end, soma);
    }

    static void sumEvenNumbers(int start, int end, int soma) {
        for (int i = start; start <= end; start++) {
            if (start % 2 == 0) {
                soma += start;
            }
        }
        System.out.println(soma);
    }
}
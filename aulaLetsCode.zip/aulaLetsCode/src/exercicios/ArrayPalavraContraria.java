package exercicios;

import java.util.Scanner;

public class ArrayPalavraContraria {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a palavra: ");
        String str = sc.nextLine().trim();
        char[] charArray = str.toCharArray();
        invertePalavra(charArray);

    }

    public static void invertePalavra(char[] charArray){
        for (int i = charArray.length - 1; 0 <= i; i--){
            System.out.println(charArray[i]);
        }

    }
}

package exercicios;

import java.util.Arrays;
import java.util.Scanner;

public class ImprimeImparesPares {

    public static void main(String[] args) {

//        Scanner sc = new Scanner(System.in);

        int[] numeros = new int[5];
        int[] numerosOrdenados = new int[5];

        criaListaDeNumeros(numeros);
        extraiNumeros(numeros, numerosOrdenados);
        mostraNumerosOrdenados(numerosOrdenados);

    }

    public static void mostraNumerosOrdenados(int[] numerosOrdenados) {
        for (int no : numerosOrdenados
        ) {
            System.out.println(no);
        }

    }

    public static void extraiNumeros(int[] numeros, int[] numerosOrdenados) {
        System.out.println("Números arrumados:");
        int contador = 0;
        for (int i = 0; i < numeros.length; i++) {
            if (numeros[i] % 2 != 0) {
                numerosOrdenados[contador] = numeros[i];
                contador += 1;
            }
        }

        for (int i = 0; i < numeros.length; i++) {
            if (numeros[i] % 2 == 0) {
                numerosOrdenados[contador] = numeros[i];
                contador += 1;
            }
        }
    }

    public static void criaListaDeNumeros(int[] listaNumeros){
        Scanner sc = new Scanner(System.in);
        for(int i = 0; i<5;i++) {
            System.out.printf("Digite o %dº número: ", i+1);
            int numero = sc.nextInt();
            listaNumeros[i] = numero;
        }
        System.out.println("Números:");
        for (int ln:listaNumeros
             ) {
            System.out.println(ln);
        }
        System.out.println();
    }

}

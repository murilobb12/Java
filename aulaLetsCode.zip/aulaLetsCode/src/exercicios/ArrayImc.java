package exercicios;

import java.util.Scanner;

public class ArrayImc {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Scanner sc1 = new Scanner(System.in);
        Scanner sc2 = new Scanner(System.in);

        double[] altura = new double[5];
        String[] nomes = new String[5];
        double[] peso = new double[5];



        int soma = 0;
        for(int i = 0; i < 5; i++){
            System.out.println("Digite o seu nome: ");
            nomes[i] = sc.nextLine();

            System.out.println("Digite a sua altura: (EX: 1,90) ");
            altura[i] = sc1.nextDouble();


            System.out.println("Digite o seu peso: (EX 92,5) ");
            peso[i] = sc2.nextDouble();
        }

        for (int i = 0; i < 5; i++){
            System.out.println("Nome: " + nomes[i] + " | Idade: " + peso[i] + " | Altura: " + altura[i]);
        }

        System.out.println("Pessoas fora do peso ideal: ");
        for (int i = 0; i<5; i++){
            if ((peso[i] / (altura[i] * altura [i])) > 25 || (peso[i] / (altura[i] * altura [i])) < 18.5){
                System.out.println(nomes[i]);
            }
        }

    }

}
package exercicios;

import java.util.Arrays;
import java.util.Scanner;

public class ArrayConvidados {


    public static void maiorConvidado(String[] convidados){

        String maiorPalavra = convidados[0];

        for (String c: convidados
        ){
            if (c.length() > maiorPalavra.length()){
                maiorPalavra = c;
            }
        }
        System.out.println("O convidado com o maior nome é o: " + maiorPalavra);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] convidados = new String[5];
        for (int i = 0; i < convidados.length; i++) {
            System.out.printf("Digite o %dº convidado: ", i + 1);
            convidados[i] = sc.nextLine();
        }
        maiorConvidado(convidados);


    }

}


package exercicios;

import java.util.Scanner;

public class ArrayUpperImpares {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Digite uma palavra: ");
        String nome = sc.next();
        transformaPalavra(nome);

    }

    public static void transformaPalavra(String palavra) {
        for (int i = 0; i < palavra.length(); i++) {
            if (i % 2 == 0) {
                System.out.println("[" + i + "] " + palavra.toLowerCase().charAt(i));
            } else {
                System.out.println("[" + i + "] " + palavra.toUpperCase().charAt(i));
            }
        }
    }


}

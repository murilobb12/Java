package exercicios;

import java.util.Scanner;

public class ArrayNomeIdade {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Scanner sc1 = new Scanner(System.in);

        int[] idade = new int[5];
        String[] nomes = new String[5];


        int soma = 0;
        for(int i = 0; i < 5; i++){
            System.out.println("Digite o seu nome: ");
            nomes[i] = sc.nextLine();

            System.out.println("Digite a sua idade ");
            idade[i] = sc1.nextInt();
            soma += idade[i];
        }

        for (int i = 0; i < 5; i++){
            System.out.println("Nome: " + nomes[i] + "| Idade: " + idade[i]);
        }

        int idadeMaisNovo = idade[0];
        String nomeMaisNovo = nomes[0];
        for (int i = 0; i < 5; i++){

            if (idade[i] < idadeMaisNovo){
                idadeMaisNovo = idade[i];
                nomeMaisNovo = nomes[i];
            }

        }

        int idadeMaisVelho = idade[0];
        String nomeMaisVelho = nomes[0];
        for (int i = 0; i < 5; i++){

            if (idade[i] > idadeMaisVelho){
                idadeMaisVelho = idade[i];
                nomeMaisVelho = nomes[i];
            }

        }
        System.out.println("----------------------");
        System.out.println("Mais novo: " +nomeMaisNovo +" Idade: "+ idadeMaisNovo);
        System.out.println("Mais velho: " +nomeMaisVelho +" Idade: "+ idadeMaisVelho);
        System.out.println("Média de idades: " + soma/idade.length);

    }

}
package exercicios.EntidadeEscola;

import java.math.BigDecimal;

public class Professor extends Pessoa implements EntidadeEscola{



    public Professor(String nome, int idade, Sexo sexo, String endereco, EstadoCivil estadoCivil, BigDecimal altura, BigDecimal peso) {
        super(nome, idade, sexo, endereco, estadoCivil, altura, peso);
    }

    @Override
    public void registrarSaida() {
        System.out.println("Professor está registrando a saída");

    }

    @Override
    public void registrarEntrada() {
        System.out.println("Professor está registrando a entrada");

    }

    @Override
    public boolean estaEmAula() {
        return false;
    }
}

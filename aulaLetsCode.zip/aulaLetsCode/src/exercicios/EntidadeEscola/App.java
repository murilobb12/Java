package exercicios.EntidadeEscola;

import java.math.BigDecimal;

public class App {

    public static void main(String[] args) {

        Aluno a = new Aluno("Murilo", 22, Pessoa.Sexo.MASCULINO, "Rua 10", Pessoa.EstadoCivil.SOLTEIRO, new BigDecimal("1.80"),  new BigDecimal("80"), 100, 1, 2);
        Professor p = new Professor("Tiago", 25, Pessoa.Sexo.MASCULINO, "Rua 20", Pessoa.EstadoCivil.SOLTEIRO, new BigDecimal("1.70"),  new BigDecimal("70"));


        System.out.println(a);
        System.out.println(p);

    }

}

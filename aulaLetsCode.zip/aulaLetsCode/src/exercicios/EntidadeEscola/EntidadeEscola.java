package exercicios.EntidadeEscola;

public interface EntidadeEscola {

    void registrarSaida();

    void registrarEntrada();

    /**
     * Método para descrever situação de estar em aula
     * @return indicação de estar em aula
     */
    boolean  estaEmAula();


}

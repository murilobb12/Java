package exercicios.EntidadeEscola;

import java.math.BigDecimal;
import java.security.Permission;

public class Aluno extends Pessoa implements EntidadeEscola {


    private int numeroMatricula;
    private int ano;
    private int numeroDeDisciplinasCompletas;

    public Aluno(String nome, int idade, Sexo sexo, String endereco, EstadoCivil estadoCivil, BigDecimal altura,
                 BigDecimal peso, int numeroMatricula, int ano, int numeroDeDisciplinasCompletas) {
        super(nome, idade, sexo, endereco, estadoCivil, altura, peso);
        this.numeroMatricula = numeroMatricula;
        this.ano = ano;
        this.numeroDeDisciplinasCompletas = numeroDeDisciplinasCompletas;
    }

    public int getNumeroMatricula() {
        return numeroMatricula;
    }

    public void setNumeroMatricula(int numeroMatricula) {
        this.numeroMatricula = numeroMatricula;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public int getNumeroDeDisciplinasCompletas() {
        return numeroDeDisciplinasCompletas;
    }

    public void setNumeroDeDisciplinasCompletas(int numeroDeDisciplinasCompletas) {
        this.numeroDeDisciplinasCompletas = numeroDeDisciplinasCompletas;
    }

    @Override
    public String toString() {
        return "Nome: " + this.getNome() + "\n"
                + "Idade: " + this.getIdade() + "\n"
                + "Sexo: " + this.getSexo() + "\n"
                + "Numero de Matrícula: " + this.getNumeroMatricula() + "\n"
                + "Ano: " + this.getAno() + "\n"
                + "Número de Disciplinas Completas: " + this.getNumeroDeDisciplinasCompletas();
    }

    @Override
    public void registrarSaida() {

        System.out.println("Aluno está registrando a saída");

    }

    @Override
    public void registrarEntrada() {
        System.out.println("Aluno está registrando a entrada");

    }

    @Override
    public boolean estaEmAula() {

        return false;

    }
}

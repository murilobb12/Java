package exercicios;

import java.util.Scanner;

public class ArrayMaiorMenorMedia {

    public static void maior(double[] numeros) {
        double maior = numeros[0];
        for (double n : numeros
        ) {
            if (n > maior) {
                maior = n;
            }
        }
        System.out.println(maior);
    }

    public static void menor(double[] numeros){
        double menor = numeros[0];
        for (double n:numeros
             ) {
            if (n< menor){
                menor = n;
            }
        }
        System.out.println(menor);
    }

    public static void media(double[] numeros){
        double resultado = 0;
        double soma = 0;
        for (double n:numeros
             ) {
            soma += n;
        }
        resultado = soma / numeros.length;
        System.out.println(resultado);
    }

    public static void main(String[] args) {


        Scanner sc = new Scanner(System.in);
        double[] numeros = new double[5];
        for (int i = 0; i < numeros.length; i++) {
            System.out.printf("Digite o %d número", i + 1);
            numeros[i] = sc.nextDouble();
        }

        System.out.print("Maior número: "); maior(numeros);
        System.out.print("Menor número: "); menor(numeros);
        System.out.print("Média dos números: "); media(numeros);
    }
}


package aulas.Tecnicas.Stream;

import java.time.LocalDate;

public class Stream2 {

    public static void main(String[] args) {

        LocalDate.now().atStartOfDay();



    }
}

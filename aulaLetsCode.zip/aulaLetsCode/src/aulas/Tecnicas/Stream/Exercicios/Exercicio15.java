package aulas.Tecnicas.Stream.Exercicios;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Exercicio15 {

    /**
     * Exercícios de streams
     * 1 - Com base na idade das pessoas, adicionar duas cadas decimais a idade
     * Dica: use bigDecimal
     *
     */


    public static void main(String[] args) {

        BancoDeDados.pegaPessoas().stream()
                .map(pessoa -> new BigDecimal(pessoa.getIdade()).setScale(2, RoundingMode.HALF_EVEN))
                .forEach(System.out::println);


    }

}

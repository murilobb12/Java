package aulas.Tecnicas.Stream.Exercicios;
public class Exercicio2 {

    /**
     * Exercícios de streams
     * Imprimir o nome das pessoas
     *
     */


    public static void main(String[] args) {

        BancoDeDados.pegaPessoas().stream()
                .map(pessoa -> pessoa.getNome())
                .forEach(System.out::println);

    }

}

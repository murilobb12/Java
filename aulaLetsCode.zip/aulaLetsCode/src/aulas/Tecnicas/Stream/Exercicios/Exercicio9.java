package aulas.Tecnicas.Stream.Exercicios;

import java.util.Comparator;

public class Exercicio9 {

    /**
     * Exercícios de streams
     *  1 - retornar uma lista com nome das três pessoas mais velhas
     *  2 - Imprimir a lista
     *
     */


    public static void main(String[] args) {

//        BancoDeDados.pegaPessoas().stream()
//                .sorted(Comparator.comparing(Pessoa::getIdade))
//                .skip(BancoDeDados.pegaPessoas().stream().count()-3)
//                .forEach(System.out::println);

        BancoDeDados.pegaPessoas().stream()
                .sorted(Comparator.comparing(Pessoa::getIdade).reversed())
                .limit(3)
                .forEach(System.out::println);

    }
}

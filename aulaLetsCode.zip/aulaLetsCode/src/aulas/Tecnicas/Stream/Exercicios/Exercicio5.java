package aulas.Tecnicas.Stream.Exercicios;
public class Exercicio5 {

    /**
     * Exercícios de streams
     *  1 - Verificar se existem pessoas sem filhos e com a quantidade de filhos > 0
     *
     */


    public static void main(String[] args) {
        BancoDeDados.pegaPessoas().stream()
                .filter(pessoa -> !pessoa.isTemFilhos() && pessoa.getFilhos() > 0)
                .forEach(System.out::println);
    }

}

package aulas.Tecnicas.Stream.Exercicios;
public class Exercicio3 {

    /**
     * Exercícios de streams
     * Imprimir as pessoas que possuam filhos
     *
     */


    public static void main(String[] args) {

        BancoDeDados.pegaPessoas().stream()
                .filter(pessoa -> pessoa.isTemFilhos())
                .forEach(System.out::println);

    }

}

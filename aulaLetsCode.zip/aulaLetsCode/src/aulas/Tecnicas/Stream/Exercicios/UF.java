package aulas.Tecnicas.Stream.Exercicios;

public enum UF {

    SP,
    RJ,
    MG,
    DF;

}

package aulas.Tecnicas.Stream.Exercicios;

import java.util.Optional;
import java.util.OptionalDouble;

public class Exercicio7 {

    /**
     * Exercícios de streams
     *  1 - Filtrar as pessoas que tem filhos
     *  2 - Encontrar a média da idade das pessoas
     *  3 - Imprimir o valor médio da idade
     *
     *   Atenção oa tratamento do optional.
     */


    public static void main(String[] args) {

        BancoDeDados.pegaPessoas().stream()
                .filter(pessoa -> pessoa.isTemFilhos())
                .map(pessoa -> pessoa.getIdade())
                .mapToInt(Integer::intValue)
                .average()
                .ifPresent(System.out::println);

    }

}

package aulas.Tecnicas.Stream.Exercicios;
public class Exercicio4 {

    /**
     * Exercícios de streams
     * Contar as pessoas que possuam filhos
     *
     */


    public static void main(String[] args) {


        int teste = (int) BancoDeDados.pegaPessoas().stream()
                  .filter(pessoa -> pessoa.isTemFilhos())
                  .count();

        System.out.println(teste);


    }

}

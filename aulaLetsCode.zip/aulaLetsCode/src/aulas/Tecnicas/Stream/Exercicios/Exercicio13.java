package aulas.Tecnicas.Stream.Exercicios;

import java.util.Comparator;
import java.util.Objects;
import java.util.stream.Collectors;

public class Exercicio13 {

    /**
     * Exercícios de streams
     * 1 - Retornar o estado com mais filhos
     * 2 - Imprimir a seguinte mensagem, interpolando as chaves pelos resultados encontrados
     *      "O estado com mais filhos é: [NOME_DO_ESTADO] o total de filhos são: [TOTAL_DE_FILHOS]
     */


    public static void main(String[] args) {

        BancoDeDados.pegaPessoas().stream()
                        .collect(Collectors.groupingBy(Pessoa::getUf, Collectors.summingDouble(Pessoa::getFilhos)))
                .entrySet()
                .stream()
                .sorted((o1, o2) -> o2.getValue().compareTo(o1.getValue()))
                .limit(1)
                .forEach(System.out::println);
        ;













    }

}

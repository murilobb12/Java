package aulas.Tecnicas.Stream.CriaNomeOptional.Interfaces;

public interface PrintName {

    public void printName();

}

package aulas.Tecnicas.Stream.CriaNomeOptional.Interfaces;

public interface Name {

    public MiddleName name(String name);

}

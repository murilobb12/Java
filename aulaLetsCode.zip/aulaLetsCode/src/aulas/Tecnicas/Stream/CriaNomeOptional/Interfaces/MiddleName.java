package aulas.Tecnicas.Stream.CriaNomeOptional.Interfaces;

public interface MiddleName {

    public LastName middleName(String middleName);

}

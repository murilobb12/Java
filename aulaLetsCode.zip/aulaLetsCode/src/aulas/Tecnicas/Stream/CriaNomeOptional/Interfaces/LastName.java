package aulas.Tecnicas.Stream.CriaNomeOptional.Interfaces;

public interface LastName {

    public PrintName lastName(String lastName);


}

package aulas.Tecnicas.Stream.CriaNomeOptional.Main;

import aulas.Tecnicas.Stream.CriaNomeOptional.Interfaces.LastName;
import aulas.Tecnicas.Stream.CriaNomeOptional.Interfaces.MiddleName;

public class CreateMiddleName implements MiddleName {

    private String name;

    public CreateMiddleName(String name) {
        this.name = name;

    }

    public LastName middleName(String middleName) {
        return null;

    }
}



package aulas.Tecnicas.Stream.CriaNomeOptional.Main;

import aulas.Tecnicas.Stream.CriaNomeOptional.Interfaces.PrintName;

public class CreatePrintName implements PrintName {
    @Override
    public void printName() {

    }
}

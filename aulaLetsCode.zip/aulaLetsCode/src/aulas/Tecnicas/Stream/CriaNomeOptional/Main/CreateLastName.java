package aulas.Tecnicas.Stream.CriaNomeOptional.Main;

import aulas.Tecnicas.Stream.CriaNomeOptional.Interfaces.LastName;
import aulas.Tecnicas.Stream.CriaNomeOptional.Interfaces.PrintName;

public class CreateLastName implements LastName {
    @Override
    public PrintName lastName(String lastName) {
        return null;
    }
}

package aulas.Tecnicas.Stream.CriaNomeOptional.Main;

import aulas.Tecnicas.Stream.CriaNomeOptional.Interfaces.MiddleName;
import aulas.Tecnicas.Stream.CriaNomeOptional.Interfaces.Name;

public class Main {

    Name name = new Name(){

        @Override
        public MiddleName name(String name) {
            return null;
        }


    };


}

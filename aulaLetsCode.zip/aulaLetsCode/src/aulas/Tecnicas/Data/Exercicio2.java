package aulas.Tecnicas.Data;

public class Exercicio2 {
}

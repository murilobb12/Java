package aulas.Julho._11.Exception;

public class InvalidUserException extends Exception{

    InvalidUserException(String mensagem){
        super(mensagem);
    }

}

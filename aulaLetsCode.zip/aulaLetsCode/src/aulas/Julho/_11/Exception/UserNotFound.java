package aulas.Julho._11.Exception;

public class UserNotFound extends Exception {

    UserNotFound(String mensagem){
        super(mensagem);
    }

}

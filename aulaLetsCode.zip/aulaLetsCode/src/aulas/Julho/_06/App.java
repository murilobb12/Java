package aulas.Julho._06;

public class App {
    public static void main(String[] args) {

        Pessoa p = new Pessoa("Murilo", "São Paulo");

        System.out.println(p.getNome());


    }
}

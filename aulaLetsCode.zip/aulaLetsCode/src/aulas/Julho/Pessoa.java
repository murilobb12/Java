package aulas.Julho;

public class Pessoa {

    private String nome;
    private short idade;
    private String sexo;
    private String endereco;
    private String estadoCivil;
    private double altura;
    private double peso;

}

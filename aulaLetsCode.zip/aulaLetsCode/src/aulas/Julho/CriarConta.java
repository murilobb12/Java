package aulas.Julho;

public class CriarConta {
    public static void main(String[] args) {

        Conta conta = new Conta();

        conta.setAgencia("1500");
        System.out.println(conta.getAgencia());

    }
}

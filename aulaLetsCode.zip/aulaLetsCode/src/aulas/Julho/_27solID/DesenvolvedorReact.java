package aulas.Julho._27solID;

public class DesenvolvedorReact implements DesenvolvedorFE{


    @Override
    public void programar(int horas) {
        System.out.println("Escrevi código React durante" + horas + " horas ");
    }

    @Override
    public void desenhaEcra() {
        System.out.println("Estou a desenvolver um ecra");

    }
}

package aulas.Julho._27solID;

public interface DesenvolvedorFE extends Desenvolvedor{

    void desenhaEcra();

}

package aulas.Julho._27solID;

public interface Desenvolvedor {

    public void programar(int horas);

}

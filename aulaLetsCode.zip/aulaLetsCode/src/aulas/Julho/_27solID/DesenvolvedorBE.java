package aulas.Julho._27solID;

public interface DesenvolvedorBE extends Desenvolvedor{

    void desenhaBD();
}

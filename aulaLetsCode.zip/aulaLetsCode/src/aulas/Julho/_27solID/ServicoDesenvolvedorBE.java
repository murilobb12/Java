package aulas.Julho._27solID;

public class ServicoDesenvolvedorBE extends ServicoDesenvolvedor{


    public ServicoDesenvolvedorBE(DesenvolvedorBE desenvolvedor) {
        super(desenvolvedor);
    }
}

package aulas.Julho;

public class Cliente {
    String nome;
    int idade;

}

package aulas.Julho._18.Generics.Exercicio;

public class Carro {

    private String cor;
    

    public Carro(String cor) {
        this.cor = cor;
    }

    public String getCor() {
        return cor;
    }

    
}

package java_.EstudosMurilo.Stream;

public enum Course {

    A1,A2;

}

package java_.EstudosMurilo.Stream;

public class Student {

    String nome;

    Course curso;

    public Student(String nome, Course curso) {
        this.nome = nome;
        this.curso = curso;
    }
}


